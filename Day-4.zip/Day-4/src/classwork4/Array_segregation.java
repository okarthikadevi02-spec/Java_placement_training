package classwork4;

import java.util.Scanner;

public class Array_segregation {
    static void main() {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] nums = new int[n];
        int i;
        for (i = 0; i < n; i += 1) {
            nums[i] = sc.nextInt();
        }
        // int[] nums={10,11,20,21,300,31,40,41}
        int c = 0, s;
        for (s = 0; s < n; s += 1) {
            if (nums[s] != 0) {
                int temp = nums[s];
                for (i = s; i > c; i += 1) {
                    nums[i] = nums[i - 1];
                }
                nums[c] = temp;
                c++;
            }
            for (int ele : nums) {
                System.out.print(ele + " ");
            }

        }
    }
}
