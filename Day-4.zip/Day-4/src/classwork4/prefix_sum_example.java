package classwork4;

import java.util.Scanner;

public class prefix_sum_example {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int[] nums=new int[n];
        int i;
        for(i=0;i<n;i+=1){
            nums[i]=sc.nextInt();
        }

        int[] prefix=new int[n];
        prefix[0]=0;
        for(i=1;i<n;i+=1){
            prefix[i]=prefix[i-1]+nums[i-1];
        }
        for(int ele:prefix){
            System.out.print(ele+" ");
        }
    }
}
