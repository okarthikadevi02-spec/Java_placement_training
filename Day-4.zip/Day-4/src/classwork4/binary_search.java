package classwork4;

import java.util.Scanner;

public class binary_search {
    static void main() {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] nums = new int[n];
        int i;
        for (i = 0; i < n; i += 1) {
            nums[i] = sc.nextInt();
        }
        int key=sc.nextInt();

        int l=0,r=n-1;
        int m;
        while(l<=r){
            m=(l+r)/2;
            if(nums[m]==key)
                break;
            else
            if(key>nums[m])
                l=m+1;
            else
                r=m-1;
        }
        if(l<=r)
            System.out.println("found");
        else System.out.println("Not found");
    }
}
