package classwork4;

import java.util.Scanner;

public class possibles_of_subarray {
    static void main() {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] nums = new int[n];
        int i;
        for (i = 0; i < n; i += 1) {
            nums[i] = sc.nextInt();
        }
        int j,k;
        for(i=0;i<n;i+=1){
            for(j=0;j<n;j++){
                for(k=i;k<=j;k++)
                    System.out.print(nums[k]+" ");
                System.out.println();
            }
        }
    }
}
