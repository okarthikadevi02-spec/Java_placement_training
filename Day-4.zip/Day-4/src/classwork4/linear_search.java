package classwork4;

import java.util.Scanner;

public class linear_search {
    static void main() {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] nums = new int[n];
        int i;
        for (i = 0; i < n; i += 1) {
            nums[i] = sc.nextInt();
        }
        int key=sc.nextInt();
        int c=0;
        for (i=0;i<n;i+=1){
            if(nums[i]==key){
                c=1;
                break;
            }

        }
        if(c==1){

            System.out.println("found: "+key);

        }
        else{
            System.out.println("Not found: "+key);
        }

    }
}