package classwork4;

import java.util.Scanner;

public class suffix_sum_example {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int[] nums=new int[n];
        int i;
        for(i=0;i<n;i+=1){
            nums[i]=sc.nextInt();
        }
        int[] suffix=new int[n];
        suffix[n-1]=nums[n-1];
        for(i=n-2;i>=0;i-=1){
            suffix[i]=nums[i]+suffix[i+1];
        }
        for(int ele:suffix){
            System.out.print(ele+" ");
        }
    }
}
