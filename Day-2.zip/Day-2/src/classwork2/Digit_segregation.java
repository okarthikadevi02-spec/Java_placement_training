package classwork2;

import java.util.Scanner;

public class Digit_segregation {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        while(n>0){
            int d;
            d=n%10;
            System.out.print(d+" ");
            n/=10;
        }
    }
}
