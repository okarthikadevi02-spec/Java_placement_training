package classwork2;

import java.util.Scanner;

public class right_triangle {

    static void main() {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int i,j;
        for (i=n;i>=1;i--){
            for(j=1;j<=i;j++){

                System.out.print("* ");

            }
            System.out.println();
        }
    }

}
