package classwork2;

import java.util.Scanner;

public class Fibonacci_series {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int f=0,s=1,t;
        int i;

        for(i=1;i<=n;i++){

            System.out.print(f+" ");
            t=f+s;
            f=s;
            s=t;

        }
    }
}
