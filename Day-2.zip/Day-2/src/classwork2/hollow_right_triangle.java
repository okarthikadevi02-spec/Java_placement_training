package classwork2;

import java.util.Scanner;

public class hollow_right_triangle {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int i,j;
        for (i=n;i>=1;i--){
            for(j=1;j<=i;j++){
                if(j==1||j==i||i==n)
                    System.out.print("* ");
                else System.out.print("  ");
            }
            System.out.println();
        }
    }

}
