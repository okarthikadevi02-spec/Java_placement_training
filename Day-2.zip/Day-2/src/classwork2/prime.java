package classwork2;

import java.util.Scanner;

public class prime {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int i;
        int count=0;
        if(n<=1){
            System.out.println("Not a prime");
            return;
        }
        for(i=2;i*i<=n;i++){
            if(n%i==0){
                count=1;
                break;
            }
        }
        if(count==0){
            System.out.println("Prime");
        }
        else{
            System.out.println("Not a prime");
        }
    }
}
