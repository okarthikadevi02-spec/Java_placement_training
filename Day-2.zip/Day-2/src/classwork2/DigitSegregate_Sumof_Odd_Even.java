package classwork2;

import java.util.Scanner;

public class DigitSegregate_Sumof_Odd_Even {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int pos=1;
        int temp=n;
        int odd=0;
        int even=0;
        while(temp>=10){
            temp=temp/10;
            pos*=10;
        }
        while(pos>0){
            int d;
            d=n/pos;
            if(d%2==0){
                even+=d;
            }
            else{
                odd+=d;
            }

            n=n%pos;
            pos/=10;
        }
        System.out.print("Even Sum is: "+even+" Odd Sum is: "+odd);
    }
}
