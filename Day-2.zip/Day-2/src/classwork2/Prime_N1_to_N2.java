package classwork2;

import java.util.Scanner;

public class Prime_N1_to_N2 {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int n1=sc.nextInt();
        int n2=sc.nextInt();
        int n,i;

        for(n=n1;n<=n2;n++){
            if(n<=1){
                continue;
            }
            int count=0;
            for(i=2;i*i<=n;i++){
                if (n % i == 0) {
                    count=1;
                    break;
                }

            }
            if(count==0){
                System.out.print(n+" ");
            }


        }
    }
}
