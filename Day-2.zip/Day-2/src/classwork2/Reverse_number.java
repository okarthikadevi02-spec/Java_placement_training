package classwork2;

import java.util.Scanner;

public class Reverse_number {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        int rev=0;
        while(num>0){
            int d;
            d=num%10;
            rev=rev*10 + d;
            num/=10;

        }
        System.out.println("Reverse Number: "+rev);
    }
}
