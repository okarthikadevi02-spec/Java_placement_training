    package classwork2;

    import java.util.Scanner;

    public class Digit_SegregationFrom_First {
        static void main() {
            Scanner sc=new Scanner(System.in);
            int n=sc.nextInt();
            int pos=1;
            int temp=n;
            while(temp>=10){
                temp=temp/10;
                pos*=10;
            }
            while(pos>0){
                int d;
                d=n/pos;
                System.out.print(d+" ");
                n=n%pos;
                pos/=10;
            }
        }
    }
