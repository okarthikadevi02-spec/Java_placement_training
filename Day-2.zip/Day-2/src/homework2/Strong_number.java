package homework2;

import java.util.Scanner;

public class Strong_number {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int s=0;
        int f;
        int temp=n;
        while(n>0){
            int d;
            d=n%10;
            f=1;
            for(int i=1;i<=d;i++){

                f=f*i;

            }
            s=s+f;
            n/=10;

        }
        if(temp==s){
            System.out.println("Strong Number");
        }
        else System.out.println("Not a Strong Number");
    }
}
