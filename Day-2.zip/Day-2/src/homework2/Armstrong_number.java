package homework2;

import java.util.Scanner;

public class Armstrong_number {
    static void main() {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int count=0;
        int temp=n;
        int num=n;
        int g,s=0;
        while(temp>0){
            temp/=10;
            count++;
        }
        while(n>0){
            int d;
            d=n%10;
            g=1;
            for(int i=1;i<=count;i++){
                g*=d;

            }
            s=s+g;
            n/=10;
        }
        if(num==s){
            System.out.print("An Armstrong Number");
        }
        else  System.out.print("Not an Armstrong Number");
    }
}
