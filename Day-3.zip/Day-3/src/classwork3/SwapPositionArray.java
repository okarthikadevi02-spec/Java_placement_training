package classwork3;

import java.util.Scanner;

public class SwapPositionArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter array size: ");
        int n = sc.nextInt();

        int[] arr = new int[n];

        System.out.println("Enter array elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.print("Enter first position: ");
        int p1 = sc.nextInt();

        System.out.print("Enter second position: ");
        int p2 = sc.nextInt();

        // Swap elements
        int temp = arr[p1];
        arr[p1] = arr[p2];
        arr[p2] = temp;

        System.out.println("Array after swapping:");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }


    }
}
