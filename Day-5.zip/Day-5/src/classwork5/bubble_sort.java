package classwork5;

import java.util.Scanner;

public class bubble_sort {
    static void main() {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] nums = new int[n];
        int i;
        for (i = 0; i < n; i += 1) {
            nums[i] = sc.nextInt();
        }
        int temp;
        int p;

        for(p=0;p<=n-2;p++){
            boolean flag=false;
            for(i=0;i<=n-2;i++){
                if(nums[i]>nums[i+1]) {

                    temp = nums[i];
                    nums[i] = nums[i + 1];
                    nums[i + 1] = temp;
                    flag=true;
                }
            }
            if(!flag){
                break;
            }
        }
        for(int ele:nums){
            System.out.print(ele+" ");
        }
    }
}
