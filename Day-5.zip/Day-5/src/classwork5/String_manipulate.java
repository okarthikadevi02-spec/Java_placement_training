package classwork5;

import java.util.Scanner;

public class String_manipulate {
    static void main() {
        Scanner input=new Scanner(System.in);
        String s=input.nextLine();
        int i;
        for (i=0;i<s.length();i++){
            System.out.print(s.charAt(i)+".");
        }
    }
}
