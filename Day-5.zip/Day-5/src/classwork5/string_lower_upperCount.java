package classwork5;

import java.util.Scanner;

public class string_lower_upperCount {
    static void main() {
        Scanner input=new Scanner(System.in);
        String s=input.nextLine();
        int l=0,u=0,d=0;
        int i;
        for (i=0;i<s.length();i++){
            char ch=s.charAt(i);
            if(ch>='A' && ch<='Z')
                u++;
            else if(ch>='a' && ch<='z')
                l++;
            else if(ch>='0' && ch<='9')
                d++;


        }
        System.out.printf("lower :"+l+"  upper :"+u+"  digits: "+d);
    }
}
