package homework1;

import java.util.Scanner;

public class Greatest_of_three {
    static void main() {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter number 1: ");
        int n1=sc.nextInt();

        System.out.print("Enter number 2: ");
        int n2=sc.nextInt();

        System.out.print("Enter number 3: ");
        int n3=sc.nextInt();

        if(n1>n2){
            if(n1>n3){
                System.out.println("The Greatest number is: "+n1);
            }
            else{
                System.out.println("The Greatest number is :"+n3);
            }
        }
        else {
            if(n2>n3){
                System.out.println("The Greatest number is :"+n2);
            }
            else{
                System.out.println("The Greatest number is :"+n3);
            }
        }
    }
}
