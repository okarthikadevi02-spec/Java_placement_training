package homework1;

import java.util.Scanner;

public class Simple_calculator {
    static void main() {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter number 1: ");
        int a=sc.nextInt();
        System.out.print("Enter number 2: ");
        int b=sc.nextInt();

        System.out.print("Enter operation(+,-,*,/,%) :" );
        char operator=sc.next().charAt(0);

        switch(operator){
            case '+':
                System.out.println("The sum is : "+(a+b));
                break;
            case '-':
                System.out.println("The Answer is : "+(a-b));
                break;
            case '*':
                System.out.println("The Answer is : "+(a*b));
                break;
            case '/':
                if(b!=0){
                    System.out.println("The Answer is : "+(a/b));
                }
                else{
                    System.out.println("Invalid Number");
                }
                break;
            case '%':
                System.out.println("The Answer is : "+(a%b));
                break;

            default:
                System.out.println("Invalid Operator");
        }
    }
}
